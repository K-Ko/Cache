
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","KKo\\Cache\\AbstractFile"],["c","KKo\\Cache\\APC"],["c","KKo\\Cache\\Cache"],["c","KKo\\Cache\\CacheException"],["c","KKo\\Cache\\File"],["c","KKo\\Cache\\Files"],["c","KKo\\Cache\\MemCache"],["c","KKo\\Cache\\Mock"]];
